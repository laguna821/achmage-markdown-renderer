Achmage Markdown Renderer portable package

1. Run achmage-reader-universal-v5.exe.
2. The portable package requires Microsoft Edge WebView2 Runtime to already be available.
3. The Windows MSI bundle includes the offline WebView2 installer path.
4. The app reads your vault but does not modify Markdown files.

Version: 5.0.0-beta.22