Achmage Markdown Renderer portable package

1. Run achmage-reader-universal-v5.exe.
2. On Windows, Microsoft Edge WebView2 Runtime must be available.
3. The app reads your vault but does not modify Markdown files.

Version: 5.0.0-beta.21